# ブロックコーダー (Next.js)

Scratch風のブロックでHTML・CSS・JSを組み立てるアプリ。

## ローカル起動
npm install
npm run dev   # http://localhost:3000

## GitHub と Vercel で公開
1. このフォルダをGitHubリポジトリにpush
2. https://vercel.com/new でリポジトリをImport
3. Framework は Next.js が自動検出されるので、そのまま Deploy
